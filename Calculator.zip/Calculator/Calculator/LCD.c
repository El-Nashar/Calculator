/*
 * LCD.c
 *
 * Created: 2020-08-08 4:26:30 PM
 *  Author: Ahmed El-Nashar
 */ 
#include "LCD.h"
#define F_CPU 16000000
#include <util/delay.h>

void LCD_Init(void)
{
	#if LCD_MODE==8
	
	DIO_SetPinDir(LCD_8BIT_CMD_PORT, LCD_RS_PIN , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_8BIT_CMD_PORT, LCD_RW_PIN , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_8BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_OUTPUT);
	
	DIO_SetPortDir(LCD_8BIT_DATA_PORT, DIO_PORT_OUTPUT);
	
	_delay_ms(100);
	
	LCD_writeCommand(0x38);
	LCD_writeCommand(0x0E);
	LCD_writeCommand(0x01);
	
	_delay_ms(5);
	
	#elif LCD_MODE==4
	
	DIO_SetPinDir(LCD_4BIT_CMD_PORT, LCD_RS_PIN , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_4BIT_CMD_PORT, LCD_RW_PIN , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_OUTPUT);
	
	DIO_SetPinDir(LCD_4BIT_DATA_PORT, LCD_D4 , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_4BIT_DATA_PORT, LCD_D5 , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_4BIT_DATA_PORT, LCD_D6 , DIO_PIN_OUTPUT);
	DIO_SetPinDir(LCD_4BIT_DATA_PORT, LCD_D7 , DIO_PIN_OUTPUT);
	
	_delay_ms(100);
	
	LCD_writeCommand(0x33); // setting the LCD to 4 bit mode
	LCD_writeCommand(0x32);		
	LCD_writeCommand(0x28); // Review Mazidi PDF for more info
	
	LCD_writeCommand(0x0C);
	LCD_writeCommand(0x01);
	LCD_writeCommand(0x06);
	LCD_writeCommand(0x02);	

	_delay_ms(5);	
	#endif
}
void LCD_writeCommand(uint8 cmd)
{
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_RS_PIN , DIO_PIN_LOW);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_RW_PIN , DIO_PIN_LOW);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_LOW);
	
	PORTA = (cmd & 0xF0) | (PORTA & 0x0F); // sending high nipple
	
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_HIGH); // latching the cmd by setting high on enable pin for 1ms.
	_delay_ms(1);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_LOW);
	
	PORTA = (cmd << 4) | (PORTA & 0x0F); // sending low nipple
	
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_HIGH); // latching the cmd by setting high on enable pin for 1ms.
	_delay_ms(1);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_LOW);
	
	_delay_ms(5);
}
void LCD_writeData(uint8 data)
{
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_RS_PIN , DIO_PIN_HIGH);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_RW_PIN , DIO_PIN_LOW);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_LOW);
	
	PORTA = (data & 0xF0) | (PORTA & 0x0F); // sending high nipple
	
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_HIGH); // latching the cmd by setting high on enable pin for 1ms.
	_delay_ms(1);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_LOW);
	
	PORTA = (data << 4) | (PORTA & 0x0F); // sending low nipple
	
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_HIGH); // latching the cmd by setting high on enable pin for 1ms.
	_delay_ms(1);
	DIO_SetPinValue(LCD_4BIT_CMD_PORT, LCD_E_PIN , DIO_PIN_LOW);
	
	_delay_ms(5);
}

void LCD_GoTo(uint8 row, uint8 col)
{
	uint8 pos[2]={0x80, 0xC0};
	LCD_writeCommand(pos[row]+col);	
}
void LCD_writeString(uint8* str)
{
	uint8 i = 0;
	while(str[i]!='\0')
	{
		LCD_writeData(str[i]);
		i++;
	}
}

void LCD_writeInteger(sint32 intgr)
{

	sint32 y = 1;

	if(intgr < 0)
	{
		LCD_writeData('-');
		intgr *= -1;
	}

	while(intgr > 0)
	{
		y = ((y*10) + (intgr%10));
		intgr /= 10;
	}

	while(y > 1 )
	{
		LCD_writeData(((y%10)+48));
		y /= 10;
	}
}

void LCD_Clear(void)
{
	LCD_writeCommand(0x01);
	_delay_ms(5);
}
