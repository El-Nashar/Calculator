/*
 * Calc.h
 *
 * Created: 2020-08-11 3:08:42 AM
 *  Author: Ahmed El-Nashar
 */ 


#ifndef CALC_H_
#define CALC_H_

#include "KeyPad.h"


sint32 get_opr1(sint32* x);
sint32 get_opr2(sint32* x);
sint32 get_operator(sint32* x);
sint32 calc(sint32 opr1, sint32 opr2, sint32 operator);




#endif /* CALC_H_ */