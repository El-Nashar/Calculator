/*
 * Calc.c
 *
 * Created: 2020-08-11 3:09:03 AM
 *  Author: Ahmed El-Nashar
 */ 
#include "KeyPad.h"
#include "LCD.h"

/*#define COL_INIT  0
#define COL_FINAL 2

#define ROW_INIT  4
#define ROW_FINAL 7

const uint8 KeyPad_Val [4][3] = {{'7','8','9'},
                                 {'4','5','6'},
                                 {'1','2','3'},
                                 {'C','0','='}};

const uint8 KeyPad_op [4] = {'/','*','-','+'};*/


										

	
sint32 get_opr1(uint8* x)
{
	uint8 j,m,k=0;	
	sint32 opr1=0;
	uint8* op1;
	
	
	for (j=0; j<=15; j++) // differentiates between 1st operand, 2nd operand and operator in between.
	{
		if (x[0]=='+' || x[0]=='-' || x[0]=='*' || x[0]=='/') // handles if user entered operator first.
			LCD_writeString("Invalid number");
				else if (x[j]=='+' || x[j]=='-' || x[j]=='*' || x[j]=='/') 
					{
						for (m=j-1; m>=0; m--) // first operand array.
						{
							op1[m] = x[m];						
						}
						
						for (k = 0; k < j; k++) // first operand as an int value.
						{
							opr1 = (10 * opr1) + (op1[k]-'0');
						}
						
					}
				}
				return opr1;
}
	
sint32 get_opr2(uint8* x)
{
	uint8 j,n,l=0;
	sint32 opr2=0;
	uint8* op2;
	
	
	for (j=0; j<=15; j++) // differentiate between 1st operand, 2nd operand and operator in between.
	{
		if (x[0]=='+' || x[0]=='-' || x[0]=='*' || x[0]=='/') // handles if user entered operator first.
		LCD_writeString("Invalid number");
		else if (x[j]=='+' || x[j]=='-' || x[j]=='*' || x[j]=='/')
		{	
			for (n=j+1; x[n]!='='; n++) // second operand array.
			{
				op2[n] = x[n];
			}
			
			for (l = 0; op2[l]!='/0'; l++) // second operand as an int value.
			{
				opr2 = (10 * opr2) + (op2[l]-'0');
			}
		}
     }
     return opr2;
}

uint8 get_operator(uint8* x)
{
	uint8 j=0;
	uint8 operator=0;
	
	for (j=0; j<=15; j++) 
	{
		if (x[j]!='=')
		{
			switch(x[j])
			{
			case '+':
				operator = 1;
			break;
			
			case '-':
			operator = 2;
			break;
			
			case '*':
			operator = 3;
			break;
			
			case '/':
			operator = 4;
			break;
			
			case '=':
			operator = 5;
			break;
			
			case 'C':
			operator = 6;
			break;
			
			default:
			break;
			}
		}
	}
	return operator;
}

sint32 calc(sint32 opr1, sint32 opr2, uint8 operator)
{
	sint32 res=0;
	
	if (operator == 6)
	{
		LCD_Clear();
	}
		else if (operator == 5)
		{
			switch (operator)
			{
				case 1:
					res = opr1+opr2;
				break;
		
				case 2:
					res = opr1-opr2;
				break;
		
				case 3:
					res = opr1*opr2;
				break;
		
				case 4:
					if (opr2 == 0)
					LCD_writeString("Div by Zero");
						else
						  res = opr1/opr2;
				break;
		}
	}
	return res;
}

					
										
										
										
								
								
								
								
								
								
								
	