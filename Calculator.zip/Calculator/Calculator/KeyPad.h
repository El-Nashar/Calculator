/*
 * KeyPad.h
 *
 * Created: 2020-08-08 7:57:13 PM
 *  Author: Ahmed El-Nashar
 */ 


#ifndef KEYPAD_H_
#define KEYPAD_H_

#include "KeyPad_Cfg.h"

void KeyPad_Init(void);
uint8 KeyPad_GetVal(void);





#endif /* KEYPAD_H_ */