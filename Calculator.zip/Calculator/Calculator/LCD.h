/*
 * LCD.h
 *
 * Created: 2020-08-08 4:26:15 PM
 *  Author: Ahmed El-Nashar
 */ 


#ifndef LCD_H_
#define LCD_H_

#include "LCD_Cfg.h"

void LCD_Init(void);
void LCD_writeCommand(uint8 cmd);
void LCD_writeData(uint8 data);
void LCD_GoTo(uint8 row, uint8 col);
void LCD_writeString(uint8* str);
void LCD_writeInteger(sint32 intgr);
void LCD_Clear(void);



#endif /* LCD_H_ */