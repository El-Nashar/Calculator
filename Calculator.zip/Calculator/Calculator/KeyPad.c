/*
 * KeyPad.c
 *
 * Created: 2020-08-08 7:58:09 PM
 *  Author: Ahmed El-Nashar
 */ 
#include "KeyPad.h"
#include "util/delay.h"


#define COL_INIT  0
#define COL_FINAL 3

#define ROW_INIT  4
#define ROW_FINAL 7

const uint8 KeyPad_Values [4][4] = {{'7','8','9','/'},
									{'4','5','6','*'},
									{'1','2','3','-'},
								    {'C','0','=','+'}};	
void KeyPad_Init(void)
{
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_COL_0, DIO_PIN_OUTPUT);
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_COL_1, DIO_PIN_OUTPUT);
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_COL_2, DIO_PIN_OUTPUT);
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_COL_3, DIO_PIN_OUTPUT);
	
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_ROW_0, DIO_PIN_INPUT);
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_ROW_1, DIO_PIN_INPUT);
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_ROW_2, DIO_PIN_INPUT);
	DIO_SetPinDir(KEYPAD_PORT, KEYPAD_ROW_3, DIO_PIN_INPUT);
	
	DIO_SetPullup(KEYPAD_PORT, KEYPAD_ROW_0);
	DIO_SetPullup(KEYPAD_PORT, KEYPAD_ROW_1);
	DIO_SetPullup(KEYPAD_PORT, KEYPAD_ROW_2);
	DIO_SetPullup(KEYPAD_PORT, KEYPAD_ROW_3);
	
	DIO_SetPinValue(KEYPAD_PORT, KEYPAD_COL_0, DIO_PIN_HIGH);
	DIO_SetPinValue(KEYPAD_PORT, KEYPAD_COL_1, DIO_PIN_HIGH);
	DIO_SetPinValue(KEYPAD_PORT, KEYPAD_COL_2, DIO_PIN_HIGH);
	DIO_SetPinValue(KEYPAD_PORT, KEYPAD_COL_3, DIO_PIN_HIGH);
	
}
uint8 KeyPad_GetVal(void)
{
	uint8 LOC_Col = 0;
	uint8 LOC_Row = 0;
	uint8 value   = 0;
	uint8 temp    = 0;
	
	for (LOC_Col = COL_INIT; LOC_Col<= COL_FINAL; LOC_Col++)
	{
		DIO_SetPinValue(KEYPAD_PORT, LOC_Col, DIO_PIN_LOW);
		
		for(LOC_Row = ROW_INIT; LOC_Row<= ROW_FINAL; LOC_Row++)
		{
			DIO_ReadPin(KEYPAD_PORT, LOC_Row, &temp);
			if (!temp)
			{
				value = KeyPad_Values[LOC_Row - ROW_INIT][LOC_Col - COL_INIT];
				
				while(!temp)
				{
					DIO_ReadPin(KEYPAD_PORT, LOC_Row, &temp);
				}
				_delay_ms(10);
			}
		}
		DIO_SetPinValue(KEYPAD_PORT, LOC_Col, DIO_PIN_HIGH);
	}
	return value;
}