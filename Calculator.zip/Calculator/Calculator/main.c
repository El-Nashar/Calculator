/*
 * Calculator.c
 *
 * Created: 2020-08-11 3:06:42 AM
 * Author : Ahmed El-Nashar
 */ 

#include "Calc.h"
#include "LCD.h"
#include "KeyPad.h"


int main(void)
{
	KeyPad_Init();
	LCD_Init();
    
	uint8 b;
	uint8 i = 0;
	uint8* x;

	
    while (1) 
    {
		    b=KeyPad_GetVal();
			if (b){ 
			for (i=0; i<15; i++)
			{
				x[i]=b;
			}
			}
	

		    sint32 a = get_opr1(&x);
			uint8 c = get_operator(&x);
			sint32 b = get_opr2(&x);
			
			sint32 res = calc(a, b, c);
			
			LCD_writeCommand(0xC0);
			LCD_writeInteger(res);
			
		
    }
}

