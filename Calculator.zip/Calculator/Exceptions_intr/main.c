/*
 * Exceptions_intr.c
 *
 * Created: 2020-08-14 3:49:50 PM
 * Author : Ahmed El-Nashar
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

